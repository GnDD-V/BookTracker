
Book Tracker — это личное веб-приложение на React для хранения, сортировки и чтения ваших книг. Оно позволяет добавлять книги, редактировать их, отслеживать статус прочтения и удобно листать содержимое постранично.

Быстрый старт

 1. Клонируйте репозиторий

git clone https://github.com/GnDD-V/BookTracker.git

 2. Установите зависимости

npm install


3. Запустите оба сервера (React + JSON Server)

- Запускает JSON Server на порту 3001
npm run serve-json

- Запускает React-приложение на порту 3000
npm start


Скрипты

npm start — запуск React-приложения
npm run serve-json — запуск json-server (локальный REST API)
npm run build — сборка production-версии

Структура проекта

src/
components/        - Navbar, Footer, Pagination, Form
context/           - BookContext (глобальное состояние)
pages/             - Главная, Добавление, Редактирование, Детали, О нас
App.js             - Основной роутинг
index.js           - Точка входа

Зависимости

React Router
Axios
json-server

API (json-server)

API работает по адресу: http://localhost:3001/books

Примеры:

GET /books — получить список книг
POST /books — добавить книгу
PUT /books/:id — обновить книгу
DELETE /books/:id — удалить книгу
 
Возможности

Добавление/удаление/редактирование книг
Постраничный просмотр текста
Сортировка по названию, автору, статусу
Роутинг без перезагрузки
Адаптивный дизайн

