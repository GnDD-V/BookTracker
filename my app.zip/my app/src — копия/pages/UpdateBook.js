import React, { useContext, useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { BookContext } from "../context/BookContext";
import BookForm from "../components/BookForm";

function UpdateBook() {
  const { id } = useParams();
  const { books, updateBook } = useContext(BookContext);
  const [current, setCurrent] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const book = books.find((b) => b.id.toString() === id);
    if (book) {
      setCurrent(book);
    }
  }, [books, id]);

  const handleUpdate = (data) => {
    updateBook(current.id, data).then(() => navigate("/"));
  };

  return (
    <>
      <h2 className="title">Редактировать книгу</h2>
      {current && <BookForm initialData={current} onSubmit={handleUpdate} />}
    </>
  );
}

export default UpdateBook;
