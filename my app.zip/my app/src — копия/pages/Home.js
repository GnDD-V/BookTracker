import React, { useContext, useState } from "react";
import { Link } from "react-router-dom";
import { BookContext } from "../context/BookContext";

function Home() {
  const { books, deleteBook } = useContext(BookContext);
  const [sortBy, setSortBy] = useState("title");

  const handleDelete = (id) => {
    if (window.confirm("Удалить эту книгу?")) {
      deleteBook(id);
    }
  };

  const sortedBooks = [...books].sort((a, b) => {
    const aVal = a[sortBy]?.toLowerCase?.() || "";
    const bVal = b[sortBy]?.toLowerCase?.() || "";
    return aVal.localeCompare(bVal);
  });

  return (
    <>
      <h2 className="title">Все книги</h2>

      <div className="sort-container">
        <label htmlFor="sort-select">Сортировать по:</label>
        <select
          id="sort-select"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
        >
          <option value="title">Названию</option>
          <option value="author">Автору</option>
          <option value="status">Статусу</option>
        </select>
      </div>

      <ul className="book-list">
        {sortedBooks.map((book) => (
          <li key={book.id} className="book-card">
            <div className="book-info">
              <Link to={`/details/${book.id}`} className="book-title">{book.title}</Link>
              <p className="book-author">by {book.author}</p>
            </div>
            <div className="actions">
              <Link to={`/edit/${book.id}`} className="button green">Редактировать</Link>
              <button onClick={() => handleDelete(book.id)} className="button red">Удалить</button>
            </div>
          </li>
        ))}
      </ul>
    </>
  );
}

export default Home;
