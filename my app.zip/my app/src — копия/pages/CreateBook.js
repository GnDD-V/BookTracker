import React, { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { BookContext } from "../context/BookContext";
import BookForm from "../components/BookForm";

function CreateBook() {
  const { addBook } = useContext(BookContext);
  const navigate = useNavigate();

  const handleAdd = (data) => {
    addBook(data).then(() => navigate("/"));
  };

  return (
    <>
      <h2 className="title">Добавить книгу</h2>
      <BookForm onSubmit={handleAdd} />
    </>
  );
}

export default CreateBook;
