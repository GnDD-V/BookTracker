import React, { useContext, useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { BookContext } from "../context/BookContext";
import BookPagination from "../components/BookPagination";

function BookDetails() {
  const { id } = useParams();
  const { books } = useContext(BookContext);
  const [book, setBook] = useState(null);

  useEffect(() => {
    const found = books.find((b) => b.id.toString() === id);
    if (found) setBook(found);
  }, [books, id]);

  return (
    <>
      {book ? (
        <>
          <h2 className="title">{book.title}</h2>
          <p><strong>Автор:</strong> {book.author}</p>
          <p><strong>Статус:</strong> {book.status}</p>
          <h3>Содержимое книги:</h3>
          <BookPagination content={book.content} />
          <Link to="/" className="button" style={{ marginTop: "1rem", display: "inline-block" }}>Назад</Link>
        </>
      ) : (
        <p>Загрузка...</p>
      )}
    </>
  );
}

export default BookDetails;
