import React, { createContext, useReducer, useEffect } from "react";
import axios from "axios";

export const BookContext = createContext();

const initialState = {
  books: []
};

function reducer(state, action) {
  switch (action.type) {
    case "SET_BOOKS":
      return { ...state, books: action.payload };
    case "ADD_BOOK":
      return { ...state, books: [...state.books, action.payload] };
    case "UPDATE_BOOK":
      return {
        ...state,
        books: state.books.map((b) =>
          b.id === action.payload.id ? action.payload : b
        )
      };
    case "DELETE_BOOK":
      return {
        ...state,
        books: state.books.filter((b) => b.id !== action.payload)
      };
    default:
      return state;
  }
}

export function BookProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    axios
      .get("http://localhost:3001/books")
      .then((res) => dispatch({ type: "SET_BOOKS", payload: res.data }))
      .catch(console.error);
  }, []);

  const addBook = (bookData) => {
    return axios
      .post("http://localhost:3001/books", bookData)
      .then((res) => {
        dispatch({ type: "ADD_BOOK", payload: res.data });
      });
  };

  const updateBook = (id, bookData) => {
    return axios
      .put(`http://localhost:3001/books/${id}`, bookData)
      .then((res) => {
        dispatch({ type: "UPDATE_BOOK", payload: res.data });
      });
  };

  const deleteBook = (id) => {
    return axios
      .delete(`http://localhost:3001/books/${id}`)
      .then(() => {
        dispatch({ type: "DELETE_BOOK", payload: id });
      });
  };

  return (
    <BookContext.Provider
      value={{
        books: state.books,
        addBook,
        updateBook,
        deleteBook
      }}
    >
      {children}
    </BookContext.Provider>
  );
}
