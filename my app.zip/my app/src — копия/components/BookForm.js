import React, { useState } from "react";

function BookForm({ initialData = { title: "", author: "", status: "To Read", content: "" }, onSubmit }) {
  const [formData, setFormData] = useState(initialData);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { title, author, status, content } = formData;
    if (title && author) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-group">
        <label>Название</label>
        <input name="title" value={formData.title} onChange={handleChange} required />
      </div>
      <div className="form-group">
        <label>Автор</label>
        <input name="author" value={formData.author} onChange={handleChange} required />
      </div>
      <div className="form-group">
        <label>Статус</label>
        <select name="status" value={formData.status} onChange={handleChange}>
          <option>В планах</option>
          <option>В процессе</option>
          <option>Прочитано</option>
        </select>
      </div>
      <div className="form-group">
        <label>Содержимое (текст книги)</label>
        <textarea name="content" value={formData.content} onChange={handleChange} rows="8" />
      </div>
      <button type="submit" className="button">Сохранить</button>
    </form>
  );
}

export default BookForm;
