import React, { useState } from "react";
import { NavLink } from "react-router-dom";

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);
  const closeMenu = () => setIsOpen(false);

  return (
    <>
      <header className="navbar">
        <h1>Book Tracker</h1>
        <button className="menu-toggle" onClick={toggleMenu}>☰</button>
      </header>

      {isOpen && (
        <>
          <nav className="dropdown-menu">
            <NavLink to="/" onClick={closeMenu}>Главная</NavLink>
            <NavLink to="/add" onClick={closeMenu}>Добавить книгу</NavLink>
            <NavLink to="/about" onClick={closeMenu}>О нас</NavLink>
          </nav>
          <div className="overlay" onClick={closeMenu}></div>
        </>
      )}
    </>
  );
}

export default Navbar;
