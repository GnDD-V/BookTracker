import React, { useState, useMemo } from "react";

const PAGE_SIZE = 3500;

function BookPagination({ content = "" }) {
  const pages = useMemo(() => {
    const result = [];
    for (let i = 0; i < content.length; i += PAGE_SIZE) {
      result.push(content.slice(i, i + PAGE_SIZE));
    }
    return result;
  }, [content]);

  const [page, setPage] = useState(0);

  const handlePrev = () => setPage((prev) => Math.max(0, prev - 1));
  const handleNext = () => setPage((prev) => Math.min(pages.length - 1, prev + 1));

  if (!content) return <p>Нет содержимого</p>;

  return (
    <div>
      <div
        style={{
          whiteSpace: "pre-wrap",
          minHeight: "300px",
          border: "1px solid #ccc",
          padding: "1rem",
        }}
      >
        {pages[page]}
      </div>

      <div className="pagination-bar">
        <button className="button" onClick={handlePrev} disabled={page === 0}>
          Предыдущая
        </button>
        <span className="pagination-info">
          Страница {page + 1} из {pages.length}
        </span>
        <button
          className="button"
          onClick={handleNext}
          disabled={page === pages.length - 1}
        >
          Следующая
        </button>
      </div>
    </div>
  );
}

export default BookPagination;
